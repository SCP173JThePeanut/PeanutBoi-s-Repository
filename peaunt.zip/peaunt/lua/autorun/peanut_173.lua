player_manager.AddValidModel("SCP-173 Peanut", "models/kaydax/peanut173/peanut_173.mdl");
list.Set("PlayerOptionsModel", "SCP-173 Peanut", "models/kaydax/peanut173/peanut_173.mdl");

